import React from 'react';
import { render, screen } from '@testing-library/react';
import Header from '../components/Header/Header';
import '@testing-library/jest-dom';

describe('Header Component', () => {
  test('renders header text correctly', () => {
    const mockText = 'Investment Calculator';
    render(<Header />);
    expect(screen.getByText(mockText)).toBeInTheDocument();
  });
});
