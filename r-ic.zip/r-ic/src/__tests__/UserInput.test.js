import React from 'react';
import { act, render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import UserInput from '../components/UserInput/UserInput';
import userEvent from '@testing-library/user-event';

describe('UserInput component', () => {
  const user = userEvent.setup();

  test('type into current savings field correctly', async () => {
    render(<UserInput />);
    const input = screen.getByLabelText('Current Savings (₹)');
    await act(async () => {
      await user.type(input, '2');
    });
    expect(input).toHaveValue(100002);
  });

  test('type into yearly savings field correctly', async () => {
    render(<UserInput />);
    const input = screen.getByLabelText('Yearly Savings (₹)');
    await act(async () => {
      await user.type(input, '2');
    });
    expect(input).toHaveValue(12002);
  });

  test('type into expected returns field correctly', async () => {
    render(<UserInput />);
    const input = screen.getByLabelText('Expected Interest (%, per year)');
    await act(async () => {
      await user.type(input, '2');
    });
    expect(input).toHaveValue(72);
  });

  test('type into investment duration field correctly', async () => {
    render(<UserInput />);
    const input = screen.getByLabelText('Investment Duration (years)');
    await act(async () => {
      await user.type(input, '2');
    });
    expect(input).toHaveValue(102);
  });
});
