import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import ResultsTable from '../components/ResultsTable/ResultsTable';

describe('ResultsTable component', () => {
  test('renders null data correctly', () => {
    render(<ResultsTable />);
    expect(
      screen.getByText(
        (content, element) => element.tagName.toLowerCase() === 'div'
      )
    ).toBeInTheDocument();
  });
  test('renders data correctly', () => {
    const mockData = [
      {
        'current-savings': 10000,
        'yearly-contribution': 1200,
        'expected-return': 7,
        duration: 10,
        year: 1,
      },
    ];
    render(<ResultsTable data={mockData} />);
    expect(screen.getByText('Year')).toBeInTheDocument();
  });
});
