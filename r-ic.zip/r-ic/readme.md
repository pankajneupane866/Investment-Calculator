<h1 align="center">Investment Calculator</h1>
This is a React-based investment calculator that allows users to calculate their investments based on their choosing.

# 💰 Features

- Pre-filled data to get user start with
- Simple but easy to use UI for starters
- Build with accessibility in mind
- Clear you input and use defaults
- Clear yearly vision your savings

# 💰 Technology

This is built using the following technologies:

- ReactJS

# 💰 How to Run the app on Your System

## Step 1: Download and Extract the Code

Firstly, download the entire apps code and extract the ZIP file to a folder on your local system.

## Step 2: Run the App

Open your code editor (such as VS Code) and navigate to the project directory. Then, open a terminal and run the following command:

```bash
npm i && npm run start
```

This will start the application. Open a web browser and navigate to http://localhost:3000 to access the website.

## Step 3: Run test cases for the App (Optional)

This app uses Jest and RTL to perform unit tests for components, to run test cases use following command:

```bash

npm run test

```
